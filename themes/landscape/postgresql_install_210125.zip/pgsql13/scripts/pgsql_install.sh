#!/bin/bash
#set -x
## Version: 1.1
## Date:    20210125
################################

#判断当前系统类型
Unamer=$(uname -v|awk '{print $1}'|awk -F - '{print $2}')
if [ "$Unamer" = "Ubuntu" ]; then
  Service=/lib/systemd/system/postgresql.service
else
  Service=/usr/lib/systemd/system/postgresql.service
fi
# 获取安装路径
PGROOT=$(dirname $PWD)
ArchScripts=$PGROOT/scripts/arch.sh
PGconf=$PGROOT/postgresql/data/postgresql.conf

postgresql_depends() {
#更新yum源为国内源并缓存元数据
#cd /etc/apt
#mv sources.list sources.list.original
#cat > sources.list <<EOF
#deb http://mirrors.ustc.edu.cn/ubuntu/ xenial main restricted universe multiverse
#deb http://mirrors.ustc.edu.cn/ubuntu/ xenial-security main restricted universe multiverse
#deb http://mirrors.ustc.edu.cn/ubuntu/ xenial-updates main restricted universe multiverse
#deb http://mirrors.ustc.edu.cn/ubuntu/ xenial-proposed main restricted universe multiverse
#deb http://mirrors.ustc.edu.cn/ubuntu/ xenial-backports main restricted universe multiverse
#deb-src http://mirrors.ustc.edu.cn/ubuntu/ xenial main restricted universe multiverse
#deb-src http://mirrors.ustc.edu.cn/ubuntu/ xenial-security main restricted universe multiverse
#deb-src http://mirrors.ustc.edu.cn/ubuntu/ xenial-updates main restricted universe multiverse
#deb-src http://mirrors.ustc.edu.cn/ubuntu/ xenial-proposed main restricted universe multiverse
#deb-src http://mirrors.ustc.edu.cn/ubuntu/ xenial-backports main restricted universe multiverse
#EOF
#pg_dump -U postgres -d coreonis -p 5432 > coreonis.sql
#psql -U postgres -d coreonis -p 5432 < coreonis.sql
 
#安装数据库依赖
if [ "$Unamer" = "Ubuntu" ]; then
/bin/ping -c 4 www.baidu.com > /dev/null 2>&1
 if [ $? -eq 0 ]; then
 apt-get -y install zlib1g-dev libreadline-dev
 apt-get -y install binutils
 apt-get -y install gcc
 apt-get -y install g++
 apt-get -y install sysstat
 apt-get -y install unixodbc unixodbc-dev
 else
 dpkg -i $PGROOT/deb/*.deb
 fi
else
/bin/ping -c 4 www.baidu.com > /dev/null 2>&1
 if [ $? -eq 0 ]; then
 yum -y install gcc gcc-c++ readline readline-devel zlib zlib-devel
 else
 rpm -iUvh $PGROOT/rpm/*.rpm --nodeps
 fi
fi
}

postgresql_system() {
#内核参数调整
sysctl -p|grep fs.file*
if [ $? -ne 0 ]; then
  echo "fs.aio-max-nr = 1048576" >>/etc/sysctl.conf
  echo "fs.file-max = 6815744" >>/etc/sysctl.conf
  echo "net.ipv4.ip_local_port_range = 9000 65500" >>/etc/sysctl.conf
  echo "net.core.rmem_default = 262144" >>/etc/sysctl.conf
  echo "net.core.rmem_max = 4194304" >>/etc/sysctl.conf
  echo "net.core.wmem_default = 262144" >>/etc/sysctl.conf
  echo "net.core.wmem_max = 1048586" >>/etc/sysctl.conf
  echo "vm.max_map_count = 262144">> /etc/sysctl.conf
  sysctl -p
else
 echo "内核参数已经调整过，跳过此步骤"
fi
#系统文件描述符和进程数调整(文件末行“# End of file”之前)
grep "65536" /etc/security/limits.conf
if [ $? -ne 0 ]; then
  echo "* soft nofile 65536" >> /etc/security/limits.conf
  echo "* hard nofile 65536" >> /etc/security/limits.conf
  echo "* soft nproc 65536" >> /etc/security/limits.conf
  echo "* hard nproc 65536" >> /etc/security/limits.conf
  echo "* hard stack 16384" >> /etc/security/limits.conf
  echo "* soft stack 10240" >> /etc/security/limits.conf
else
 echo "文件描述符和进程数调整，跳过此步骤"
fi
 }

postgresql_install() {

#环境变量配置
grep "PGHOME" /etc/profile
if [ $? -ne 0 ]; then
cat >> /etc/profile <<EOF
export PGHOME=$PGROOT/postgresql
export PGDATA=$PGROOT/postgresql/data
export PATH=$PATH:$PGROOT/postgresql/bin
EOF
source /etc/profile
else
echo "环境变量已配置，跳过此步骤"
fi
which psql
if [ $? -ne 0 ]; then
# 解压
tar zxf $PGROOT/stage/postgresql-13.1.tar.gz -C $PGROOT/stage
#unzip $PGROOT/stage/pldebugger.zip -d $PGROOT/stage/
# 编译postgresql
cd $PGROOT/stage/postgresql-13.1&&./configure --prefix=$PGROOT/postgresql
# 安装postgresql
make -j4&&make install
# 编译安装pldbgapi
#cd $PGROOT/stage/pldebugger&&USE_PGXS=1 make clean&&USE_PGXS=1 make&&USE_PGXS=1 make install
 if [ $? -eq 0 ]; then
#用户和组创建
 id -u postgres
  if [ $? -ne 0 ]; then
   groupadd postgres
   useradd -g postgres -m postgres
   echo "postgres:erc@81977100" | chpasswd
   #echo "DenyUsers postgres" >> /etc/ssh/sshd_config
   #systemctl reload sshd
  else
   echo "用户和组已经存在，跳过此步骤"
  fi
#安装目录权限设置
  chmod -R 755 $PGROOT/postgresql
  chown -R postgres:postgres $PGROOT/postgresql
  chown -R postgres:postgres $PGROOT/archivedir
  chown postgres:postgres $ArchScripts&&chmod u+x $ArchScripts
# 初始化
  su - postgres -lc "$PGROOT/postgresql/bin/initdb -D $PGROOT/postgresql/data"
# 替换配置文件
  if [ $? -eq 0 ];then
   cp -f $PGROOT/conf/*.conf $PGROOT/postgresql/data/
  else
   echo "初始化不成功，跳过配置文件替换"
  fi
else
exit 4
 fi
else
exit 4
fi
}

postgresql_services() {
# 注册服务
cat >$Service<<\EOF
[Unit]
Description=PostgreSQL 13 database server
Documentation=https://www.postgresql.org/docs/13/static/
After=syslog.target
After=network.target

[Service]
Type=forking

User=postgres
Group=postgres

# Note: avoid inserting whitespace in these Environment= lines, or you may
# break postgresql-setup.

# Location of database directory
Environment=PGPORT=11543
Environment=PGDATA=pgroot/postgresql/data

# Where to send early-startup messages from the server (before the logging
# options of postgresql.conf take effect)
# This is normally controlled by the global default set by systemd
# StandardOutput=syslog

# Disable OOM kill on the postmaster
OOMScoreAdjust=-1000
Environment=PG_OOM_ADJUST_FILE=/proc/self/oom_score_adj
Environment=PG_OOM_ADJUST_VALUE=0

ExecStart=pgroot/postgresql/bin/pg_ctl start -D ${PGDATA} -s -o "-p ${PGPORT}" -w -t 300  
# ExecStop=pgroot/postgresql/bin/pg_ctl stop -D ${PGDATA} -s -m fast  
# ExecReload=pgroot/postgresql/bin/pg_ctl reload -D ${PGDATA} -s
ExecReload=/bin/kill -HUP $MAINPID
KillMode=mixed
KillSignal=SIGINT
 

# Do not set any timeout value, so that systemd will not kill postmaster
# during crash recovery.
TimeoutSec=0

[Install]
WantedBy=multi-user.target
EOF
# 修改PGHOME
sed -i "s:pgroot:$PGROOT:g" $Service
sed -i "s:archroot:$PGROOT:g" $ArchScripts
sed -i "s:archroot:$PGROOT:g" $PGconf
# 启动和自起
systemctl restart postgresql
systemctl enable postgresql
systemctl status postgresql
}

# 设置管理员密码，默认管理员postgres密码为空
alter_user() {
Dalive=`$PGROOT/postgresql/bin/pg_isready -p 11543 -U postgres 2>&1 >> /dev/null&&echo $?`
if [ $Dalive -eq 0 ];then
  $PGROOT/postgresql/bin/psql -p 11543 -U postgres postgres -c "alter user postgres password 'erc@81977100'"
else
  echo "数据库没有正常启动，启动后手动执行！"
fi
}

Install() {
postgresql_depends
postgresql_system
postgresql_install
postgresql_services
alter_user
}
Install 2>&1 | tee $(pwd)/install.log
